
import AVFoundation
import UIKit


// delegate which used to detect when the AVSynthesizer is done with speaking.

public protocol speakDelegate{
    func languageEnd()
    func wasteEnd()
    func calenderEnd()
    func screenshotEnd()
    func siriGreeting1()
    func siriGreeting2()
}




// Class which contains all functions to play media in this playground.
// When conforming to a delegate I made a extension of this class
public class Media: NSObject{
    
    public var delegate: speakDelegate?
    private var notifications: NSObjectProtocol!
    public var audioPlayer = AVAudioPlayer()
    private var dialogue = AVSpeechUtterance(string: "")
    private let synth = AVSpeechSynthesizer()
    private var player = AVPlayer.init()
    
    // I've created a singeltone of this class because then there's no need of multiple instances of the media class. 
    public static let sharedInstance = Media()
  
    public func play(MediaName: String, Mediatyp: String = "mp3"){
        
        do{
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: MediaName, ofType: Mediatyp)!))
            
            audioPlayer.prepareToPlay()
            audioPlayer.isMeteringEnabled = true
            audioPlayer.updateMeters()
        }catch{
            print(error)
        }
        
        audioPlayer.play()
        if audioPlayer.play() == false{
            audioPlayer.play()
        }
    }
    
    
    public override init() {
        
    }
    
    
    
    open func speak(text: String, language: String = "en-US"){
        dialogue = AVSpeechUtterance(string: text)
        dialogue.rate = AVSpeechUtteranceDefaultSpeechRate
        dialogue.voice = AVSpeechSynthesisVoice(language: language)
        synth.delegate = self
        synth.speak(dialogue)
    }
    
    
    public func playVideo(playingView: UIView) -> AVPlayerItem {
        let url = Bundle.main.url(forResource: "Intro", withExtension: "mov")!
        player.volume = 10
        player.replaceCurrentItem(with: AVPlayerItem.init(url: url))
        player.play()
        let playerLayer = AVPlayerLayer.init(player: player)
        
        playerLayer.frame = playingView.layer.frame
        playingView.layer.addSublayer(playerLayer)
        player.actionAtItemEnd = .pause
        
        return player.currentItem!
    }
    
    
    
    
}

// extension to conform to delegate -> clearer code!
// This is more or less the heart of the control flow of the playground.
extension Media: AVSpeechSynthesizerDelegate {
    
    
    
    public func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
        switch utterance.speechString {
            
        case Constants.siriGreeting1:
            delegate?.siriGreeting1()
        case Constants.siriGreeting2:
            delegate?.siriGreeting2()
        case Constants.languageModeText:
            delegate?.languageEnd()
        case Constants.trashModeText:
            delegate?.wasteEnd()
        case Constants.screenShotText:
           delegate?.screenshotEnd()
        case Constants.calendarText:
            delegate?.calenderEnd()
        case Constants.moreIdeasText:
            Media.sharedInstance.play(MediaName: "One more thing…")
        default:
            printCommands.freeLine()
        }
    }
    
    // timing for the wasteScene 
    public func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, willSpeakRangeOfSpeechString characterRange: NSRange, utterance: AVSpeechUtterance) {
        if utterance.speechString == Constants.trashModeText{
          
            switch characterRange {
            case NSRange(location: 118, length: 5):
                NotificationCenter.default.post(name: Constants.showRenew, object: self)
            case NSRange(location: 256, length: 4):
                NotificationCenter.default.post(name: Constants.showDustbin, object: self)
            case NSRange(location: 332, length: 4):
                NotificationCenter.default.post(name: Constants.showCreateMl, object: self)
            default:
                printCommands.freeLine()
            }
        }
        
    }

}







