

import SpriteKit
import UIKit

// rename Functions 
// function for adding Nodes. Also clearer code and less duplication
public func AddNSKode(Texture: String, Size: CGSize, Position: CGPoint, Dynamic: Bool, Gravity: Bool, bitMask: Bool = true) -> SKSpriteNode{
    
    
    let texture = SKTexture(image: UIImage.init(named: Texture)!)
    let tempSKSprite = SKSpriteNode(texture: texture, color: .clear, size: Size)
    tempSKSprite.position = Position
    
    
    if bitMask == true {
    tempSKSprite.physicsBody = SKPhysicsBody.init(rectangleOf: Size)
    tempSKSprite.physicsBody?.isDynamic = Dynamic
    tempSKSprite.physicsBody?.affectedByGravity = Gravity
    tempSKSprite.physicsBody?.categoryBitMask = Constants.mediaBitmask
    tempSKSprite.physicsBody?.collisionBitMask = Constants.mediaBitmask
    tempSKSprite.physicsBody?.contactTestBitMask = Constants.wallBitmask
    }
    tempSKSprite.alpha = 0.0
    
    return tempSKSprite
}


public func addNodes(text: String) -> SKLabelNode{
    
    let tempLabel = SKLabelNode()
    // var physicsBody = SKPhysicsBody(rectangleOf: tempLabel.frame.size)
    tempLabel.text = text
    //  label.color = .black
    tempLabel.fontColor = randomColour()
    tempLabel.fontName = "Helvetica-Bold"
    tempLabel.fontSize = 40
    tempLabel.position = CGPoint.init(x: diceRoll().x, y: diceRoll().y)
    tempLabel.physicsBody = SKPhysicsBody.init(rectangleOf: tempLabel.frame.size)
    tempLabel.physicsBody?.isDynamic = true
    tempLabel.physicsBody?.affectedByGravity = true
    tempLabel.physicsBody?.isResting = false
    tempLabel.physicsBody?.applyForce(CGVector.init(dx: 0.02, dy: 0.02))
    
    return tempLabel
}


public class CustomSKView: SKView {
    
    
    let leaveBTN = UIButton()
    let againBTN = UIButton()
    
    let gravityControllerHorizontal = UISlider.init()
    let gravityControllerVertical = UISlider.init()

    
    override public init(frame: CGRect) {
        super.init(frame: frame)
        self.frame = frame
        self.backgroundColor = .black
    }
    
    
    
    // Set up the view with the right controlles rigth in the init statment. 
    
    public convenience init(scene: SKScene) {
        self.init(frame: Constants.viewScreenFrame)
        
        
        self.presentScene(scene)
        
        if scene.name == "MoreIdeas"{
            
            configurationView(GenericUI: gravityControllerHorizontal, Type: 5, SuperView: self, Frame: CGRect(x: 100, y: 400, width: 200, height: 20), Background: .clear, Action: #selector(setGravityVertical), target: self)
            
            configurationView(GenericUI: gravityControllerVertical, Type: 5, SuperView: self, Frame: CGRect(x: 100, y: 500, width: 200, height: 20), Background: .clear, Action: #selector(setGravityHorizontal), target: self)
            
            configurationView(GenericUI: leaveBTN, Type: 1, SuperView: self, Frame: CGRect(x: 75, y: 530, width: 230, height: 50), Border: (cornerRadius:25, width: 1, colour:.clear), Text: ("Go on!", .black, 20), Background: .gray)
            
            
            configurationView(GenericUI: againBTN, Type: 1, SuperView: self, Frame: CGRect(x: 75, y: 600, width: 230, height: 50), Border: (cornerRadius:25, width: 1, colour:.clear), Text: ("Recenter ideas!", .black, 20), Background: .gray)
            
            againBTN.addTarget(self, action: #selector(playAgain), for: .touchUpInside)
            
          
            leaveBTN.addTarget(self, action: #selector(dismissScene), for: .touchUpInside)
            
            Media.sharedInstance.speak(text: Constants.moreIdeasText)
            
        }
    }

    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc func dismissScene() {
        NotificationCenter.default.post(name: Constants.showEnding, object: self)
    }
    
    @objc func playAgain(){
        let castedScene = self.scene as! MoreIdeas
        castedScene.reCenterLabelNodes()
    }
    
    

    @objc func setGravityVertical() {
        self.scene!.physicsWorld.gravity = CGVector.init(dx: Double(gravityControllerHorizontal.value), dy: 0.0)
    }
    
    @objc func setGravityHorizontal() {
        self.scene!.physicsWorld.gravity = CGVector.init(dx: 0.0, dy: Double(gravityControllerVertical.value))
    }
    
}





public class MoreIdeas: SKScene{
    let image = UIImage.init(named: "Notch light.png")
    var backGroundNode = SKSpriteNode()    
    
    var tempPhysicsBody = SKPhysicsBody.init()
    var label = SKLabelNode()
    let moreIdeas = ["Personal Siri Voice", "New Xcode Logo", "Memoji exportable as 3D model", "Eye tracking in Apple Books", "Calender is recognizing Holidays", "improved screenrecording", "Set prefered Wi-FI Connections", "Warning of stain in your Face", "Case mode for iOS"]
    let oldAppleColours: [UIColor] = [UIColor.blue]
    
    
    override public func didMove(to view: SKView) {
        
        backGroundNode.texture = SKTexture.init(image: image!)
        backGroundNode.position = CGPoint(x: 187, y: 330)
        backGroundNode.size = Constants.viewScreenFrame.size
        backGroundNode.name = "Background"
        
        self.addChild(backGroundNode)
        self.backgroundColor = .white
        self.physicsWorld.gravity = CGVector.init(dx: 0.0, dy: 0.0)
       
        addLabelNodes()
      
    }
    
    public override init() {
        super.init(size: Constants.viewScreenFrame.size)
        self.size = Constants.viewScreenFrame.size
        self.name = "MoreIdeas"
    }
    
    public func reCenterLabelNodes() {
        for child in self.children {
            if child.name == "Background" {
                
            }else {
                child.removeFromParent()
            }
        }
        self.addLabelNodes()
    }
    
    func addLabelNodes(){
        for idea in moreIdeas {
            label = addNodes(text: idea)
            self.addChild(label)
        }
    }
    
    public required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
}




public class AppleInversion: SKScene {
    
    var fade = SKAction.fadeIn(withDuration: 0.7)
    
    let possibleAppleLogos = ["Apple logo.jpg", "Apple logo 2.jpg", "Apple logo 3.jpg", "Apple logo 4.jpg", "Apple logo 5.jpg", "Apple logo 6.jpg", "Apple logo 7.jpg", "Apple logo 8.jpg"]
    
    var appleLogo1: SKSpriteNode{
        return AddNSKode(Texture: possibleAppleLogos[0], Size: CGSize(width: 70, height: 70), Position: CGPoint(x: 265, y: 55), Dynamic: true, Gravity: false)
    }
  
    override public func didMove(to view: SKView) {
        
        self.physicsBody = SKPhysicsBody.init(edgeLoopFrom: CGRect(x: 0, y: 0, width: 375, height: 668))
        self.physicsWorld.contactDelegate = self
        self.physicsBody?.categoryBitMask = Constants.wallBitmask
        self.physicsBody?.collisionBitMask = Constants.mediaBitmask
        self.physicsBody?.contactTestBitMask = Constants.mediaBitmask
        
        self.size = Constants.viewScreenFrame.size
        self.backgroundColor = UIColor.init(rgb: 0xfafafa)
        self.createAmess()
    }
    
    func createAmess() {
        for _ in 0...50{
            let appleLogo = self.appleLogo1
            appleLogo.texture = SKTexture.init(image: UIImage.init(named: possibleAppleLogos[diceRoll(input1: possibleAppleLogos.count - 1).x])!)
            appleLogo.position = CGPoint(x: diceRoll().x, y: diceRoll().y)
            appleLogo.zPosition = 1.0
            self.addChild(appleLogo)
            appleLogo.run(fade)
            appleLogo.physicsBody?.applyAngularImpulse(0.1)
            
        }
    }
}

// Removes the apples when they leave the viewable scene. That's for a better performance. 

extension AppleInversion: SKPhysicsContactDelegate {
    
     public func didEnd(_ contact: SKPhysicsContact) {
        contact.bodyB.node?.removeFromParent()
    }
    
}

