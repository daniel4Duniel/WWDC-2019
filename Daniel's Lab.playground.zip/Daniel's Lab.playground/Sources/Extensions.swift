import UIKit
import ImageIO



// function to compare values. 

fileprivate func < <T : Comparable>(left: T?, right: T?) -> Bool {
    switch (left, right) {
    case let (l?, r?):
        return l < r
    case (nil, _?):
        return true
    default:
        return false
    }
}


// extension to run Gifs as an UIImage
// it returns a UIImage and the duration how long it takes till the gif has run through. 


public extension UIImage {

    public class func gifImageWithName(_ name: String) -> (UIImage?,Double?) {
        guard let bundleURL = Bundle.main
            .url(forResource: name, withExtension: "gif") else {
                return (nil,nil)
        }
        guard let imageData = try? Data(contentsOf: bundleURL) else {
            return (nil,nil)
        }
        
        return gifImageWithData(imageData)
    }
    
    
    public class func gifImageWithData(_ data: Data) -> (UIImage?, Double?) {
        guard let source = CGImageSourceCreateWithData(data as CFData, nil) else {
            return (nil,nil)
        }
        
        
        return UIImage.animatedImage(source)
    }

    class func delayForImageAtIndex(_ index: Int, source: CGImageSource!) -> Double {
        var delay = 0.1
        
        let cfProperties = CGImageSourceCopyPropertiesAtIndex(source, index, nil)
        let gifProperties: CFDictionary = unsafeBitCast(
            CFDictionaryGetValue(cfProperties,Unmanaged.passUnretained(kCGImagePropertyGIFDictionary).toOpaque()),
            to: CFDictionary.self)
        
        var delayObj: AnyObject = unsafeBitCast(
            CFDictionaryGetValue(gifProperties,Unmanaged.passUnretained(kCGImagePropertyGIFUnclampedDelayTime).toOpaque()),            to: AnyObject.self)
        if delayObj.doubleValue == 0 {
            delayObj = unsafeBitCast(CFDictionaryGetValue(gifProperties,Unmanaged.passUnretained(kCGImagePropertyGIFDelayTime).toOpaque()), to: AnyObject.self)
        }
        
        delay = delayObj as! Double
        
        if delay < 0.1 {
            delay = 0.1
        }
        
        return delay
    }
    
    class func gcdOfPair(_ a: Int?, _ b: Int?) -> Int {
        var a = a
        var b = b
        if b == nil || a == nil {
            if b != nil {
                return b!
            } else if a != nil {
                return a!
            } else {
                return 0
            }
        }
        
        if a < b {
            let c = a
            a = b
            b = c
        }
        
        var rest: Int
        while true {
            rest = a! % b!
            if rest == 0 {
                return b!
            } else {
                a = b
                b = rest
            }
        }
    }
    
    class func gcdForArray(_ array: Array<Int>) -> Int {
        if array.isEmpty {
            return 1
        }
        var gcd = array[0]
        for val in array {
            gcd = UIImage.gcdOfPair(val, gcd)
        }
        return gcd
    }
    
    class func animatedImage(_ source: CGImageSource) -> (UIImage?, Double?) {
        
        let count = CGImageSourceGetCount(source)
        var images = [CGImage]()
        var delays = [Int]()
        
        for i in 0..<count {
            if let image = CGImageSourceCreateImageAtIndex(source, i, nil) {
                images.append(image)
            }
            let delaySeconds = UIImage.delayForImageAtIndex(Int(i),source: source)
            delays.append(Int(delaySeconds * 1000.0)) // Seconds to ms
        }
        
        let duration: Int = {
            var sum = 0
            for value: Int in delays {
                sum += value
            }
            return sum
        }()
        
        let gcd = gcdForArray(delays)
        var frames = [UIImage]()
        
        var frame: UIImage
        var frameCount: Int
        for i in 0..<count {
            frame = UIImage(cgImage: images[Int(i)])
            frameCount = Int(delays[Int(i)] / gcd)
            
            for _ in 0..<frameCount {
                frames.append(frame)
            }
        }
        
        let animation = UIImage.animatedImage(with: frames, duration: Double(duration) / 1000.0)
        return (animation, Double(duration) / 1000.0)
    }
}


// extension to init a UIColor with a HexCode


public extension UIColor {
    convenience init(red: Int, green: Int, blue: Int) {
        assert(red >= 0 && red <= 255, "bad red component")
        assert(green >= 0 && green <= 255, "bad green component")
        assert(blue >= 0 && blue <= 255, "bad blue component")
        
        self.init(red: CGFloat(red) / 255.0, green: CGFloat(green) / 255.0, blue: CGFloat(blue) / 255.0, alpha: 1.0)
    }
    
    convenience init(rgb: Int) {
        self.init(
            red: (rgb >> 16) & 0xFF,
            green: (rgb >> 8) & 0xFF,
            blue: rgb & 0xFF
        )
    }
}

// extension which is used to render a UImage out of an UIView
public extension UIView {
    
    func asImage() -> UIImage {
        let renderer = UIGraphicsImageRenderer(bounds: bounds)
        return renderer.image { rendererContext in
            layer.render(in: rendererContext.cgContext)
        }
    }
}
