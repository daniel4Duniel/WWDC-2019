import UIKit


public struct printCommands {
    public static func freeLine(){
        print( "          ")
    }
    
    public static func bugMessage() {
        print("Oh crap we ran into a bug!")
    }
    
}


public func randomColour() -> UIColor{
    let red = drand48()
    let green = drand48()
    let blue = drand48()
    
    return UIColor(displayP3Red: CGFloat(red), green: CGFloat(green), blue: CGFloat(blue), alpha: 1.0)
}


public func diceRoll(input1: Int = 360, input2: Int = 200) -> (x: Int, y: Int) {
    let Number = Int(arc4random_uniform(UInt32(input1)))
    let Number2 = Int(arc4random_uniform(UInt32(input2))) + Number * 2
    return (Number, Number2)
}


public func animateTableView(_ tableView: UITableView){
    
    tableView.reloadData()
    let cells = tableView.visibleCells
    
    let tableViewHeight = tableView.bounds.size.height
    
    for cell in cells {
        cell.transform = CGAffineTransform(translationX: 0, y: tableViewHeight)
    }
    
    var delayCounter = 0
    
    for cell in cells {
        UIView.animate(withDuration: 1.75, delay: Double(delayCounter) * 0.05, usingSpringWithDamping: 0.8, initialSpringVelocity: 0, options: .curveEaseOut, animations: {
            cell.transform = CGAffineTransform.identity
        }, completion: nil)
        delayCounter += 1
        
    }
    
}





//This structure stores frequently used values. 

public struct Constants{
   
  
    public static let viewScreenFrame = CGRect(x: 0, y: 0, width: 375, height: 668)
  
    public static let mediaBitmask: UInt32 = 0b0001
    public static let wallBitmask: UInt32 = 0b0010
    
    public static let showEnding = Notification.Name("Ending")
    
    public static let showRenew = Notification.Name("showRenew")
    
    public static let showDustbin = Notification.Name("showDustbin")
    
    public static let showCreateMl = Notification.Name("showCreateMl")
    
    public static let siriGreeting1 = "Ok I got you covered! Hi it's me siri and I will show and guide you through Daniel's Lab. Here are four buttons."
    
    
    public static let siriGreeting2 = "which each will lead you to an idea. After you tried all we will discover some more. Keep in mind that these scenes are just some demos for the ideas and not full working."
    
    
    
    public static let screenShotText =
    "Welcome to the screenshot section. In the opening gif you have seen the current way to take a screenshot in iOS. In this scene I would like to demonstrate the screenshot tinder like interface. Swipe right to keep the screenshot, swipe up to edit and swipe left to drop the shot at all."
    
    
    public static let languageModeText =
    "LA stands for the language learn mode! As you maybe know, to keep your language skills you have to practice them quiet often. That's why I'm proposing a mode in iOS which changes the system language in specific times. Just press the switch multiple times and the mode will randomly select one language"
    
    
    
    public static let trashModeText = "Waste is a extremely important topic to talk about. It is a great threat to our environment and a problem which Apple cares deeply about. What if the camera of your iphone could tell you in which dustbin your gabage has to go to be completely recycled? Or even a dustbin which sorts trash on its own? I see that as a very interesting area for CreateML."
    
    
    public static let calendarText = "In this scene you will discover an amazing new feature of the calendar. It is detecting specific keywords like birthday in the event creation and sets it automatically on repeat yearly. Set a date and choose one keyword and the calender will decide if it should repeat yearly!"

    
    public static let bridgeText = "So you made it! These were some of my ideas. But We're just getting started."
    
    
    public static let moreIdeasText = "Here are more ideas. If you would like to read them more clearly, please use the sliders on the bottom. Use the power of gravity to move them around! But please don't stick around for so long because"
    
    public static let endingText = "So this was Daniel's lab and it was a pleasure for me to be your Guide. Daniel and I hope that you liked his playground and that you reward his work with a scholarship to the WWDC 19.  On this last site you're able to get to know Daniel a little bit better. Just match the things he likes and dislikes on the PickerViews! So thank you for your attention and hopefully see you soon.Your Siri and Daniel!"
}


// These functions are created to reduce redundanr code and make my intentions clearer

public func setUpTimer(duration: Double, selector: Selector, target: Any?){
    if let unwrappedTarget = target{
        Timer.scheduledTimer(timeInterval: duration, target: unwrappedTarget, selector: selector, userInfo: nil, repeats: false)
    }
}

public func setUpSwipeRecognizer(recognizer: UISwipeGestureRecognizer, direction: UISwipeGestureRecognizer.Direction? = nil, selector: Selector, addView: UIView, target: Any?) {
    if direction != nil {
        recognizer.direction = direction!
    }
    if let unwrappedTarget = target {
        recognizer.addTarget(unwrappedTarget, action: selector)
        addView.addGestureRecognizer(recognizer)
    }
    
}

public func getGifData(imageName: String) -> (UIImage, Double){
    
    let tempdata: (UIImage?, Double?)
    tempdata =  UIImage.gifImageWithName(imageName)
    let imageData = tempdata.0 ?? UIImage()
    let durationData = tempdata.1 ?? 1.0
    return (imageData, durationData)
}

// I wrote this function to reduce the mess of code when adding a lot of UI elements to a Superview. Thanks to this function a can add multiple types of UI elements in one line of code.

public func configurationView<View>(GenericUI: View, Type: Int, SuperView: UIView? = nil, Frame: CGRect, Border: (cornerRadius: Int?, width: Int?, colour: UIColor)? = nil, Text: (String, UIColor, Int)? = nil, image: UIImage? = nil, Background: UIColor = .white, Action: Selector? = nil, target: Any? = nil ) where View: UIView  {
    
    
    switch Type {
    case 0:
        fallthrough
    case 1:
        if Type == 1 {
            let btn = GenericUI as! UIButton
            btn.setTitle(Text?.0, for: .normal)
            
            if let UnwrapedImage = image{
                btn.setImage(UnwrapedImage, for: .normal)
            }
            
            btn.tintColor = .black
            btn.setTitleColor(Text?.1, for: .normal)
            btn.titleLabel?.font = UIFont.init(name:  "HelveticaNeue-Bold", size: CGFloat((Text?.2)!))
            
            
            if let unwrappedBorderData = Border{
                if let unwrappedCornerRadius = unwrappedBorderData.cornerRadius{
                    btn.imageView?.layer.cornerRadius = CGFloat(unwrappedCornerRadius)
                }
            }
     
            if Action != nil {
                  btn.addTarget(target, action: Action!, for: .touchUpInside)
            }
        }
        fallthrough
    case 2:
        if Type == 2 {
            let label = GenericUI as! UILabel
            if let TextAppereance = Text {
                label.text = TextAppereance.0
                label.font = UIFont.init(name:  "HelveticaNeue-Bold", size: CGFloat(TextAppereance.2))
                label.textColor = TextAppereance.1
            }
        }
        fallthrough
    case 3:
        if Type == 3 {
            let scrollView = GenericUI as! UIScrollView
            if let UnwrapedImage = image{
                let subImageView = UIImageView(frame: Frame)
                subImageView.image = UnwrapedImage
                subImageView.addSubview(scrollView)
                SuperView?.addSubview(subImageView)
            }
        }
        fallthrough
        
        
    case 4:
        if Type == 4{
            let imageView = GenericUI as! UIImageView
            if let UnwrapedImage = image{
                imageView.image = UnwrapedImage
            }
            
            if let unwrappedBorder = Border {
                if let unwrappedCornerRadius = unwrappedBorder.cornerRadius {
                    imageView.layer.cornerRadius = CGFloat(unwrappedCornerRadius)
                    imageView.layer.masksToBounds = true
                }
            }
            
        }
        fallthrough
    
    case 5:
        if Type == 5 {
            let slider = GenericUI as! UISlider
            slider.addTarget(target, action: Action!, for: .valueChanged)
            slider.maximumValue = 0.5
            slider.minimumValue = -0.5
            slider.value = 0.0
        }
    fallthrough

    default:
        GenericUI.frame = Frame
        GenericUI.backgroundColor = Background
        
        if Type != 3 {
            SuperView?.addSubview(GenericUI)
        }
        GenericUI.layer.borderWidth = CGFloat(Border?.1 ?? 0)
        GenericUI.layer.borderColor = Border?.2.cgColor ?? UIColor.clear.cgColor
        GenericUI.layer.cornerRadius = CGFloat(Border?.0 ?? 0)
    }
}

