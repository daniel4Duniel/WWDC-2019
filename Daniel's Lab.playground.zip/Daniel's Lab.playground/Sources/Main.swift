
import UIKit
import PlaygroundSupport
import AVFoundation


public class DynamicCalendarView: UIView{
    private let date = UILabel()
    private let day = UILabel()
    
    override public init(frame: CGRect) {
        super.init(frame: frame)
        self.frame = frame
        self.backgroundColor = .white
        self.layer.cornerRadius = 20
        self.layer.borderColor = UIColor.black.cgColor
        self.layer.borderWidth = 1.0
    }
    
    required public init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
   public func setDate(digit: Int, day: String) {
        self.date.frame = CGRect.init(x: 10, y: 10, width: self.frame.width, height: self.frame.height)
        self.date.font = UIFont.init(name: "HelveticaNeue-UltraLight", size: 70)
        self.date.text = String(digit)
        self.addSubview(self.date)
    
    
        self.day.frame = CGRect.init(x: 14, y: 5, width: self.frame.width, height: 30)
        self.day.font = UIFont.init(name: "HelveticaNeue-Light", size: 20)
        self.day.textColor = UIColor.init(rgb: 0xdc241c)
        self.day.text = day
        self.addSubview(self.day)
    
        if day == "Wednesday"{
        self.day.frame = CGRect.init(x: 5, y: 5, width: self.frame.width, height: 30)
        self.day.font = UIFont.init(name: "HelveticaNeue-Light", size: 17)
        }
    
    
    }
    
}

func weekdayInString(day: Int) -> String {
    
    switch day{
    case 2:
        return "Monday"
    case 3:
        return "Tuesday"
    case 4:
        return "Wednesday"
    case 5:
        return "Thursday"
    case 6:
        return "Friday"
    case 7:
        return "Saturday"
    case 1:
        return "Sunday"
    default:
        printCommands.bugMessage()
    }
    return ""
}


// Created this Structure and its Substructures to enable easier access to the UI Elements and to bring order to these many elements.

struct UIElements {
    
    static let background = UIImageView()
    
    struct HomeScreen {
        static var screenShotBtn = UIButton()
        static var calenderBtn = UIButton()
        static var languageBtn = UIButton()
        static var trashBtn = UIButton()
        static var siriBtn = UIButton()
    }
    
    struct WelcomeScreen {
        static let greeting = UIImageView()
        static let slideToUnlock = UIImageView()
        static let swipeRecognizer = UISwipeGestureRecognizer.init()
        static let skView = CustomSKView.init(scene: AppleInversion())
    }
    
    struct ScreenshotScene {
        static let screenshotImage = UIImageView.init()
        static let explanationLabel = UILabel()
        static let screenshotGif = UIImageView()
        static let rightSwipe = UISwipeGestureRecognizer.init()
        static let leftSwipe = UISwipeGestureRecognizer.init()
        static let upSwipe = UISwipeGestureRecognizer.init()
    }
    
    struct WasteScene {
        static let wasteGifsView = UIImageView.init()
    }
    
    struct LanguageScene {
        static let currentLanguage = UILabel()
        static let possibleLanguagesTable = UITableView()
        static let modeLabel = UITextView()
        static let modeSwitch = UISwitch()
    }
    
    struct CalendarScene {
        static let keyWordPicker = UIPickerView()
        static let datePicker = UIDatePicker()
        static let saveBtn = UIButton()
        static let dynamicCalendar = DynamicCalendarView()
        static let showRepetitionSwitch = UISwitch()
        static let repetitionLabel = UILabel()
    }
    
    struct EndingScene {
        static let moreIdeasGame = CustomSKView.init(scene: MoreIdeas())
        static let ending = EndingScreen()
    }
    
}

// values which will set to true when the sythesizer has finished with speaking. This is to prevent that the user is leaving the scene during the explanation. I try to cover every possibile state without creating a bug.

struct SiriStatus {
    static var screenshotDone = false
    static var languageDone = false
    static var calendarDone = false
}


public class MainScreen: UIViewController{
    
    
    var notifications: NSObjectProtocol!
    
    // checks if you discovered all four scenes.
    var checkedAllFeatures = (false, false, false, false)
    
    func checkFeatures() {
        if checkedAllFeatures == (true, true, true, true){
            Media.sharedInstance.speak(text:Constants.bridgeText)
            UIElements.background.removeFromSuperview()
            self.view.addSubview(UIElements.EndingScene.moreIdeasGame)
            notifications = NotificationCenter.default.addObserver(forName: Constants.showEnding, object: UIElements.EndingScene.moreIdeasGame, queue: OperationQueue.main) { notification in
                UIElements.EndingScene.moreIdeasGame.presentScene(nil)
                UIElements.EndingScene.moreIdeasGame.removeFromSuperview()
                self.view.addSubview(EndingScreen.init())
            }
        }
    }
  
    
    override public func viewDidLoad() {
        
        print("Hi there, welcome to my Playground!")
        
        
        UIElements.WelcomeScreen.slideToUnlock.image = UIImage.gifImageWithName(("Slide to unlock")).0
        
        UIElements.WelcomeScreen.slideToUnlock.frame = CGRect(x: 50, y: 400, width: 200, height: 100)
        
        UIElements.background.addSubview(UIElements.WelcomeScreen.slideToUnlock)
        self.view.frame = Constants.viewScreenFrame
        // to archive the exact color which is in the slide to unlock gif.
        self.view.backgroundColor = UIColor.init(rgb: 0x2f2f2f)
        
        // change it to the UIIMageView inn the configuraationView
        configurationView(GenericUI: UIElements.background, Type: 4, SuperView: self.view, Frame: CGRect(x: 35, y: 10, width: 300, height: 650)
            , image: UIImage.init(named: "Notch.png"), Background: .clear)
        
        
        configurationView(GenericUI: UIElements.WelcomeScreen.greeting, Type: 4, SuperView: UIElements.background
            , Frame: CGRect(x: 10, y: 100, width: 280, height: 200),  image: UIImage.init(named: "Hello.png"), Background: .clear)
        
        
        printCommands.freeLine()
        print("To explore it please follow the written and spoken instructions.")
        printCommands.freeLine()
        print("Be also sure that the volume of your mac is turned up!")
        
        setUpSwipeRecognizer(recognizer: UIElements.WelcomeScreen.swipeRecognizer, selector: #selector(getToMainPart), addView: self.view, target: self)
    }
    
    
    @objc private func getToMainPart() {
        Media.sharedInstance.play(MediaName: "Unlock sound")
        self.view.addSubview(UIElements.WelcomeScreen.skView)
        self.view.sendSubviewToBack(UIElements.WelcomeScreen.skView)
        print("Some ideas for some improvements.")
        UIElements.WelcomeScreen.slideToUnlock.removeFromSuperview()
        UIElements.WelcomeScreen.greeting.image = nil
        UIElements.background.image = UIImage.init(named: "Notch light.png")
        self.view.backgroundColor = .white
        let playerItem = Media.sharedInstance.playVideo(playingView: UIElements.WelcomeScreen.greeting)
        NotificationCenter.default.addObserver(self, selector: #selector(playerDidFinishPlaying),
                                               name: NSNotification.Name.AVPlayerItemDidPlayToEndTime, object:playerItem)
        
        self.view.removeGestureRecognizer(UIElements.WelcomeScreen.swipeRecognizer)
        
    }

    
    @objc public func playerDidFinishPlaying(note: NSNotification) {
        UIElements.WelcomeScreen.greeting.removeFromSuperview()
        UIElements.WelcomeScreen.skView.presentScene(nil)
        UIElements.WelcomeScreen.skView.removeFromSuperview()
       
       UIElements.background.image = nil
        self.view.backgroundColor = .black
        
        newSiriGifData = UIImage.gifImageWithName("Siri New Gif")
        
        
        configurationView(GenericUI: newImageView, Type: 4, SuperView: self.view, Frame: CGRect(x: -30, y: 100, width: 500, height: 300),  image: newSiriGifData!.0, Background: .clear)
        
    
        Timer.scheduledTimer(timeInterval: newSiriGifData!.1! - 0.5, target: self, selector: #selector(setUpHomeScreen), userInfo: nil, repeats: false)
        
        UIView.animate(withDuration: 4.5) {
            self.newImageView.alpha = 0.0
        }
        
    }
    
    
    
    @objc private func setUpHomeScreen(){
        
        Media.sharedInstance.delegate = self
        
        Media.sharedInstance.speak(text: Constants.siriGreeting1)
        
        self.view.backgroundColor = .white
        
        newImageView.removeFromSuperview()
        
        configurationView(GenericUI: UIElements.background, Type: 4, SuperView: self.view, Frame: CGRect(x: 35, y: 10, width: 300, height: 650)
            , image: UIImage.init(named: "Notch robot.png"), Background: .clear)
        
        
        configurationView(GenericUI: UIElements.HomeScreen.screenShotBtn, Type: 1, SuperView: self.view, Frame: CGRect(x: 70, y: 130, width: 100, height: 100), Border: (cornerRadius:25, width: 1, colour:.clear), Text: ("?", .gray, 40), image: UIImage.init(named: "Screenshot icon.jpg"), Background: .clear, Action: #selector(startScreenshot), target: self)
        
        configurationView(GenericUI: UIElements.HomeScreen.trashBtn, Type: 1, SuperView: self.view, Frame: CGRect(x: 200, y: 130, width: 100, height: 100), Border: (cornerRadius:25, width: 0, colour:.clear), Text: ("?", .gray, 40), image: UIImage.init(named: "Trashcan.png"), Background: .gray, Action: #selector(startTrash), target: self)
        
        configurationView(GenericUI: UIElements.HomeScreen.languageBtn, Type: 1, SuperView: self.view, Frame: CGRect(x: 70, y: 400, width: 100, height: 100), Border: (cornerRadius:25, width: 0, colour:.clear), Text: ("LA", .black, 40), Background: .gray, Action: #selector(startLanguageScene), target: self)
        
        configurationView(GenericUI: UIElements.HomeScreen.calenderBtn, Type: 1, SuperView: self.view, Frame: CGRect(x: 200, y: 400, width: 100, height: 100), Border: (cornerRadius:25, width: 0, colour:.clear), Text: ("?", .gray, 40), image: UIImage.init(named: "Calender icon.jpg"), Background: .gray, Action: #selector(startCalendarScene), target: self)
        
        configurationView(GenericUI: UIElements.HomeScreen.siriBtn, Type: 1, SuperView: self.view, Frame: CGRect(x: 115, y: 280, width: 150, height: 100), Border: (cornerRadius:30, width: 0, colour:.clear), Text: ("?", .gray, 40), image: UIImage.gifImageWithName("Siri animation").0, Background: .clear)
        
        
        UIElements.HomeScreen.calenderBtn.alpha = 0.0
        UIElements.HomeScreen.languageBtn.alpha = 0.0
        UIElements.HomeScreen.trashBtn.alpha = 0.0
        UIElements.HomeScreen.screenShotBtn.alpha = 0.0
        
    }
    

    
    public func defaultSetUPScene(btn: UIButton) {
        switch btn{
            
        case UIElements.HomeScreen.calenderBtn:
            Media.sharedInstance.speak(text: Constants.calendarText)
        case UIElements.HomeScreen.languageBtn:
            Media.sharedInstance.speak(text: Constants.languageModeText)
        case UIElements.HomeScreen.screenShotBtn:
            Media.sharedInstance.speak(text: Constants.screenShotText)
        case UIElements.HomeScreen.trashBtn:
            Media.sharedInstance.speak(text: Constants.trashModeText)
            
        default:
            print("Hello World")
        }
        UIView.animate(withDuration: 1.0) {
            btn.center = CGPoint(x: 180, y: 150)
        }
        fadeIcons(btn: btn)
    }
    
    
    

    func fadeIcons(btn: UIButton) {
        for element in self.view.subviews {
            if element == btn  || element == UIElements.background {
            }else {
                element.alpha = 0.0
            }
        }
    }
    
    func animateIcons(removeElement: UIButton? = nil) {
        for element in self.view.subviews {
            if element == UIElements.background {
            }else {
                element.alpha = 0.0
            }
        }
        
        UIView.animate(withDuration: 1.0)  {
            for element in self.view.subviews {
                if element == removeElement {
                    element.removeFromSuperview()
                }
                element.alpha = 1.0
            }
        }
    }
    
    ///////////////////////////////////////
    // Values for the calender
    
    var date = Date()
    let calendar = Calendar.current

    let calenderKeywords = ["Birthday" : 1, "Dentist appointment": 0, "date of death": 1, "Work": 0, "wedding day": 1, "Apple Keynote": 0, "Couple Day": 1]
    
    var calenderKeys: [String] {
        return Array(calenderKeywords.keys)
    }
    
    @objc func startCalendarScene(){
    
        Media.sharedInstance.play(MediaName: "Calender sound")
        UIElements.HomeScreen.calenderBtn.removeTarget(self, action: #selector(startCalendarScene), for: .touchUpInside)
        defaultSetUPScene(btn: UIElements.HomeScreen.calenderBtn)
        
     
        date =  UIElements.CalendarScene.datePicker.date
      
        
        UIView.animate(withDuration: 1.0){
            UIElements.HomeScreen.calenderBtn.center = CGPoint(x: 180, y: 150)
        }

        
        configurationView(GenericUI: UIElements.CalendarScene.datePicker, Type: 6,SuperView: self.view, Frame: CGRect(x: 36, y: 200, width: 310, height: 100))
        configurationView(GenericUI: UIElements.CalendarScene.showRepetitionSwitch, Type: 6, SuperView: self.view, Frame: CGRect(x: 220, y: 470, width: 50, height: 50), Background: .clear)
        configurationView(GenericUI: UIElements.CalendarScene.keyWordPicker, Type: 6, SuperView: self.view, Frame: CGRect(x: 36, y: 300, width: 300, height: 100))
        configurationView(GenericUI: UIElements.CalendarScene.saveBtn, Type: 1, SuperView: self.view, Frame: CGRect(x: 75, y: 520, width: 230, height: 50), Border: (cornerRadius:25, width: 1, colour:.clear), Text: ("Leave & Back", .black, 20), Background: .gray)
        configurationView(GenericUI: UIElements.CalendarScene.repetitionLabel, Type: 2, SuperView: self.view, Frame: CGRect(x: 80, y: 470, width: 150, height: 30), Text: ("Yearly repeat:", .white, 20), Background: .clear)
        
        
        UIElements.CalendarScene.dynamicCalendar.frame = CGRect(x: 130, y: 100, width: 100, height: 100)
        UIElements.CalendarScene.saveBtn.addTarget(self, action: #selector(dismissCalendarScene), for: .touchUpInside)
        UIElements.CalendarScene.datePicker.addTarget(self, action: #selector(setDate), for: .valueChanged)
        UIElements.CalendarScene.dynamicCalendar.setDate(digit: calendar.component(.day, from: date), day: weekdayInString(day: calendar.component(.weekday, from: date)))
        self.view.addSubview(UIElements.CalendarScene.dynamicCalendar)
        self.view.bringSubviewToFront(UIElements.CalendarScene.dynamicCalendar)
        
        UIElements.CalendarScene.keyWordPicker.delegate = self
        UIElements.CalendarScene.keyWordPicker.dataSource = self
        
    }
    
    @objc func setDate(){
        date =  UIElements.CalendarScene.datePicker.date
        
        UIElements.CalendarScene.dynamicCalendar.setDate(digit: calendar.component(.day, from: date), day: weekdayInString(day: calendar.component(.weekday, from: date)))
    }
    
    @objc func dismissCalendarScene() {
        
        // if there's still some theme playing, stop it when the calender scene is removed.
        
        Media.sharedInstance.audioPlayer.stop()
        

        if SiriStatus.calendarDone {
            checkedAllFeatures.2 = true
            checkFeatures()
            
            UIElements.CalendarScene.keyWordPicker.removeFromSuperview()
            UIElements.CalendarScene.datePicker.removeFromSuperview()
            UIElements.CalendarScene.saveBtn.removeFromSuperview()
            UIElements.CalendarScene.dynamicCalendar.removeFromSuperview()
            UIElements.CalendarScene.repetitionLabel.removeFromSuperview()
            UIElements.CalendarScene.showRepetitionSwitch.removeFromSuperview()
            
            UIElements.background.image = UIImage.init(named: "Notch skull.png")
            animateIcons(removeElement: UIElements.HomeScreen.calenderBtn)
        }
    }
    
    /////////////////////////////////////////////////////
    
    @objc func startTrash() {
        Media.sharedInstance.play(MediaName: "Trash sound")
        
        defaultSetUPScene(btn: UIElements.HomeScreen.trashBtn)
        
        let wasteGifData = getGifData(imageName: "Waste")
        
        UIElements.WasteScene.wasteGifsView.layer.cornerRadius = 20
        UIElements.WasteScene.wasteGifsView.layer.masksToBounds = true
        
        configurationView(GenericUI: UIElements.WasteScene.wasteGifsView, Type: 4, SuperView: self.view, Frame: CGRect(x: -30, y: 100, width: 500, height: 300),  image: wasteGifData.0, Background: .clear)
        
        setUpTimer(duration: wasteGifData.1, selector: #selector(changeGif), target: self)
        
        notifications = NotificationCenter.default.addObserver(forName: Constants.showRenew, object: Media.sharedInstance, queue: OperationQueue.main) { notification in
            UIView.animate(withDuration: 0.5) {
                 UIElements.WasteScene.wasteGifsView.frame = CGRect(x: 85, y: 100, width: 200, height: 300)
                 UIElements.WasteScene.wasteGifsView.image = UIImage.init(named: "Renew.png")
            }
            
        }
        
        
        notifications = NotificationCenter.default.addObserver(forName: Constants.showDustbin, object: Media.sharedInstance, queue: OperationQueue.main) { notification in
            
            Media.sharedInstance.play(MediaName: "Laughing")
            
            UIView.animate(withDuration: 0.5) {
                UIElements.WasteScene.wasteGifsView.frame = CGRect(x: 0, y: 100, width: 400, height: 300)
            }
            
            
            UIElements.WasteScene.wasteGifsView.image = UIImage.init(named: "iMac trashcan.jpg")
        }
    
        notifications = NotificationCenter.default.addObserver(forName: Constants.showCreateMl, object: Media.sharedInstance, queue: OperationQueue.main) { notification in
            UIElements.WasteScene.wasteGifsView.image = UIImage.init(named: "CreateML.jpg")
        }
        

    }
    
    
    @objc func changeGif(){
        let liamGifData = getGifData(imageName: "Liam gif")
        UIElements.WasteScene.wasteGifsView.image = liamGifData.0
    }
   
    
    func dismissWasteScene(){
        animateIcons(removeElement: UIElements.HomeScreen.trashBtn)
        UIElements.WasteScene.wasteGifsView.removeFromSuperview()
    }
    
    
    ////////////////////////////////////////////////////
    
    var tempImage = UIImage()
    var checkingDirections = (false, false, false)
    
 
    @objc func startScreenshot() {
        
        
        UIElements.HomeScreen.screenShotBtn.removeTarget(self, action: #selector(startScreenshot), for: .touchUpInside)
        
        defaultSetUPScene(btn: UIElements.HomeScreen.screenShotBtn)
        
        let gifData = UIImage.gifImageWithName("Screenshot gif")
        
        
        configurationView(GenericUI: UIElements.ScreenshotScene.screenshotGif, Type: 4, SuperView: self.view, Frame: CGRect(x: 35, y: 200, width: 300, height: 400)
            , image: gifData.0, Background: .clear)
        
        
        // To dismiss the Gif when it`s run through.
        Timer.scheduledTimer(timeInterval: gifData.1!, target: self, selector: #selector(takeScreenShot), userInfo: nil, repeats: false)
      
    }
    
    
    
    @objc func takeScreenShot() {
        
       // DispatchQueue.main.async {
            setUpSwipeRecognizer(recognizer: UIElements.ScreenshotScene.rightSwipe, direction: .right, selector: #selector(self.saveScreenshot), addView: self.view, target: self)
            
            setUpSwipeRecognizer(recognizer: UIElements.ScreenshotScene.leftSwipe, direction: .left, selector: #selector(self.deleteScreenshot), addView: self.view, target: self)
            
            setUpSwipeRecognizer(recognizer: UIElements.ScreenshotScene.upSwipe, direction: .up, selector: #selector(self.editScreenshot), addView: self.view, target: self)
      //  }
        
     
        Media.sharedInstance.play(MediaName: "Camera sound")
 
        
        
        // View which should create a "flash" during the Screenshot process
        UIElements.ScreenshotScene.screenshotImage.frame = self.view.frame
        
        
        configurationView(GenericUI: UIElements.ScreenshotScene.explanationLabel, Type: 2, SuperView: self.view, Frame: CGRect.init(x: UIElements.HomeScreen.screenShotBtn.center.x - 70, y: UIElements.HomeScreen.screenShotBtn.center.y + 80, width: 300, height: 20), Text: ("Start and swipe!", .white, 20), Background: .clear)
        
        // uses my custom extension to create a UIImage out of the UIView
        tempImage = self.view.asImage()
        
        
        // change the animation's Speed
        UIView.animate(withDuration: 0.5) {
            UIElements.ScreenshotScene.screenshotImage.backgroundColor = .white
            self.view.addSubview(UIElements.ScreenshotScene.screenshotImage)
        }
        
        UIView.animate(withDuration: 0.5) {
            
            UIElements.ScreenshotScene.screenshotImage.frame = CGRect(x: 126, y: 450, width: 120, height: 200)
            UIElements.ScreenshotScene.screenshotImage.image = self.tempImage
        }
        
        
        UIElements.ScreenshotScene.screenshotGif.removeFromSuperview()
        
    }
    
    
    @objc func removeScreenShotView() {
        UIElements.ScreenshotScene.screenshotGif.removeFromSuperview()
    }
    
    
    
    func animateScreenShot(newPosition: CGPoint){
        UIView.animate(withDuration: 0.5, animations: {UIElements.ScreenshotScene.screenshotImage.center = newPosition
        }, completion: {(true) in
            UIView.animate(withDuration: 1.0, animations:  {UIElements.ScreenshotScene.screenshotImage.frame = CGRect(x: 126, y: 450, width: 120, height: 200)})
        })
        
        
    }
    
    func CheckDirections(){
        if checkingDirections == (true, true, true) {
            UIElements.HomeScreen.screenShotBtn.setImage(nil, for: .normal)
            UIElements.HomeScreen.screenShotBtn.setTitle("Back", for: .normal)
            UIElements.HomeScreen.screenShotBtn.addTarget(self, action: #selector(dismissScreenshotScene), for: .touchUpInside)
        }
    }
    
    
    @objc func dismissScreenshotScene() {
        if SiriStatus.screenshotDone {
        UIElements.ScreenshotScene.screenshotImage.removeFromSuperview()
        UIElements.ScreenshotScene.screenshotGif.removeFromSuperview()
        UIElements.ScreenshotScene.explanationLabel.removeFromSuperview()
        animateIcons(removeElement: UIElements.HomeScreen.screenShotBtn)
        checkedAllFeatures.3 = true
        UIElements.background.image = UIImage.init(named: "Notch robot.png")
        checkFeatures()
        }
    }
    
    
    @objc func deleteScreenshot(){
        UIElements.ScreenshotScene.explanationLabel.text = "Delete screenshot!"
        animateScreenShot(newPosition: CGPoint.init(x: -50, y: 550))
        checkingDirections.0 = true
        CheckDirections()
    }
    
    @objc func editScreenshot(){
        UIElements.ScreenshotScene.explanationLabel.text = "edit Screenshot!"
        animateScreenShot(newPosition: CGPoint.init(x: 175, y: -100))
        checkingDirections.1 = true
        CheckDirections()
        
    }
    
    @objc func saveScreenshot(){
        UIElements.ScreenshotScene.explanationLabel.text = "save Screenshot!"
        animateScreenShot(newPosition: CGPoint.init(x: 500, y: 550))
        checkingDirections.2 = true
        CheckDirections()
        
    }
    
    
    
    
    ////////////////////////////////////////////////////

    
    private var languageData = ["English", "German", "French", "Croatian"]
    

    
    func setLanguage(_ language: String){
        
        switch language {
        case languageData[0]:
            UIElements.LanguageScene.currentLanguage.text = "iOS language: \(language)"
        case languageData[1]:
            UIElements.LanguageScene.currentLanguage.text = "iOS Sprache: \(language)"
        case languageData[2]:
            UIElements.LanguageScene.currentLanguage.text = "iOS langue: \(language)"
        case languageData[3]:
            UIElements.LanguageScene.currentLanguage.text = "iOS jezik: \(language)"
            
        default:
            printCommands.freeLine()
        }
    }
    
    
    
    @objc func setRandomLanguage(){
        
       var index = IndexPath.init(row: diceRoll(input1: (languageData.count), input2: (languageData.count)).x, section: 0)
        
        UIElements.LanguageScene.possibleLanguagesTable.selectRow(at: index, animated: false, scrollPosition: UITableView.ScrollPosition.none)
        self.setLanguage(languageData[index.row])
    }
    
    
    @objc func switchTriggered(){
        if UIElements.LanguageScene.modeSwitch.isOn {
            self.setRandomLanguage()
        } else if UIElements.LanguageScene.modeSwitch.isOn == false {
            self.setLanguage(languageData[0])
            UIElements.LanguageScene.possibleLanguagesTable.selectRow(at: IndexPath.init(item: 0, section: 0), animated: true, scrollPosition: .none)
            UIElements.HomeScreen.languageBtn.setTitle("Back", for: .normal)
        }
    }
    
    
    @objc func startLanguageScene() {
        
        Media.sharedInstance.play(MediaName: "Language sound")
        
        defaultSetUPScene(btn: UIElements.HomeScreen.languageBtn)
        
        
        UIView.animate(withDuration: 1.0){
            UIElements.HomeScreen.languageBtn.center = CGPoint(x: 180, y: 150)
        }
        
        configurationView(GenericUI: UIElements.LanguageScene.currentLanguage, Type: 2, SuperView: self.view, Frame:  CGRect(x: 50, y: 180, width: 300, height: 70), Text: ("iOS Language: English", .white, 20), Background: .clear)
        
        configurationView(GenericUI: UIElements.LanguageScene.modeLabel, Type: 6, SuperView: self.view, Frame:  CGRect(x: 40, y: 500, width: 300, height: 200), Text: ("Change the system language randomly through all the languages you know!", .white, 10), Background: .clear)
        
        configurationView(GenericUI: UIElements.LanguageScene.modeSwitch, Type: 6, SuperView: self.view, Frame:  CGRect(x: 155, y: 470, width: 50, height: 50), Background: .clear)
        
        UIElements.LanguageScene.modeSwitch.addTarget(self, action: #selector(switchTriggered), for: .valueChanged)
        UIElements.HomeScreen.languageBtn.removeTarget(self, action: #selector(startLanguageScene), for: .touchUpInside)
        UIElements.HomeScreen.languageBtn.addTarget(self, action: #selector(dismissLanguageScene), for: .touchUpInside)
        
        
        configurationView(GenericUI: UIElements.LanguageScene.possibleLanguagesTable, Type: 6, SuperView: self.view, Frame: CGRect(x: 35, y: 245, width: 300, height: 200))
        
        UIElements.LanguageScene.possibleLanguagesTable.dataSource = self
        UIElements.LanguageScene.possibleLanguagesTable.delegate = self
        
        UIElements.LanguageScene.modeLabel.text = "This mode changes the system language randomly through all the languages you know! Just click the switch!"
        UIElements.LanguageScene.modeLabel.isEditable = false
        UIElements.LanguageScene.modeLabel.textColor = .white
        
        animateTableView(UIElements.LanguageScene.possibleLanguagesTable)
    }
    
  
    @objc func dismissLanguageScene() {
        if SiriStatus.languageDone {
        checkedAllFeatures.0 = true
        UIElements.background.image = UIImage.init(named: "Notch alien.png")
        checkFeatures()
        animateIcons(removeElement: UIElements.HomeScreen.languageBtn)
        UIElements.LanguageScene.modeLabel.removeFromSuperview()
        UIElements.LanguageScene.possibleLanguagesTable.removeFromSuperview()
        UIElements.LanguageScene.currentLanguage.removeFromSuperview()
        UIElements.LanguageScene.modeSwitch.removeFromSuperview()
        }
    }

    
    ////////////////////////////////////////////////////////////////////////////////////////
    
    
    var newImageView = UIImageView()
    var newSiriGifData: (UIImage?, Double?)?
  
}

// Extentendet the main class to conform to specific Protocols



extension MainScreen: UIPickerViewDataSource, UIPickerViewDelegate {
    
    
    public func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    public func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return calenderKeys.count
    }
    
    public func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
      
        return calenderKeys[row]
    }
    
    public func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
       
        if calenderKeywords[calenderKeys[row]] == 1 {
            UIElements.CalendarScene.showRepetitionSwitch.isOn = true
        }else {
            UIElements.CalendarScene.showRepetitionSwitch.isOn = false
        }
        
        let chosenWord = calenderKeys[row]
        
        switch chosenWord {
        case "Birthday":
            Media.sharedInstance.play(MediaName: "Happy birthday")
        case "wedding day":
            Media.sharedInstance.play(MediaName: "Wedding sound")
        case "Apple Keynote":
            Media.sharedInstance.play(MediaName: "Jony I")
        case "date of death":
            Media.sharedInstance.audioPlayer.stop()
        default:
            Media.sharedInstance.play(MediaName: "Boring")
        }
    }
}


extension MainScreen: UITableViewDataSource, UITableViewDelegate {
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return languageData.count
    }
    
    // Provide a cell object for each row.
   public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // Fetch a cell of the appropriate type.
        let cell = UITableViewCell.init(frame: CGRect.init(x: 0, y: 0, width: tableView.frame.width, height: 20))
        
        // Configure the cell’s contents.
        cell.textLabel!.text = languageData[indexPath.row]
        return cell
    }
    
    public func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.setLanguage(languageData[indexPath.row])
    }

}


extension MainScreen: speakDelegate {
    public func languageEnd(){
        SiriStatus.languageDone = true
        print("Please stay not so long in the languageScene... We still have a lot to cover!")
    }
    public func wasteEnd(){
        checkedAllFeatures.1 = true
        UIElements.background.image = UIImage.init(named: "Notch bear.png")
        checkFeatures()
        dismissWasteScene()
    }
    public func calenderEnd(){
        SiriStatus.calendarDone = true
        print("Please stay not so long in the CalendarScene... We still have a lot to cover!")
    }
    public func screenshotEnd(){
        SiriStatus.screenshotDone = true
        print("Please stay not so long in the ScreenshotScene... We still have a lot to cover!")
    }
    public func siriGreeting1(){
        Media.sharedInstance.speak(text: Constants.siriGreeting2)
         self.animateIcons()
    }
    public func siriGreeting2(){
        Media.sharedInstance.play(MediaName: "Siri Stop")
        UIView.animate(withDuration: 0.75) {
            UIElements.HomeScreen.siriBtn.alpha = 0.0
        }
       UIElements.HomeScreen.siriBtn.removeFromSuperview()
    }

}
