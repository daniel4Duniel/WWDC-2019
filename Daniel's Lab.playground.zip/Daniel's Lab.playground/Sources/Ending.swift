import UIKit


// Create a game in which you have to aligne the different pickerviews to the same symbol!

// Find the things I like and don't like

protocol dontLikePickerDelegate {
    func chosenPicker(emoji: String)
 
}


public class DontLikePicker: UIPickerView {
    
    var customDelegate: dontLikePickerDelegate?
    
    var dontLikeElements = ["🌶", "🌧", "😔", "🐞", "📺", "🔇", "😡", ";" ]
    
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
        self.frame = frame
        self.delegate = self
        self.dataSource = self
        self.layer.borderWidth = 3
        self.layer.borderColor = UIColor.gray.cgColor
        self.layer.cornerRadius = 20
    }
    
    public required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
}



extension DontLikePicker: UIPickerViewDataSource, UIPickerViewDelegate {
    
    public func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    public func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return dontLikeElements.count
    }
    
    public func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return dontLikeElements[row]
    }
    
    public func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        customDelegate?.chosenPicker(emoji: dontLikeElements[row])
    }
    
    public func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        let label = UILabel()
        label.font = UIFont.init(name: "Helvetica", size: 25)
        label.text = dontLikeElements[row]
        label.textAlignment = .center
        return label
    }
    
}





public class EndingScreen: UIView {
    
    
    let iphoneShape = UIImageView.init()
    let swiftIcon = UIImageView()
    let xcodeIcon = UIImageView()
    let topicLabel = UILabel()
    var likePicker = UIPickerView()
    var dontLikePicker = DontLikePicker(frame: CGRect.init(x: 270, y: 200, width: 50, height: 200))
    var caption = UILabel()
    var finderSad = UIImageView()
    var finderHappy = UIImageView()
    var WWDC19 = UIImageView()
    
 
    var dontLikeObject = ""
    var likeObject = ""
    
    let planeEmoji = UILabel()
    let germanyFlag = UILabel()
    let usaFlag = UILabel()
    let endingBlurview = UIVisualEffectView.init(effect: UIBlurEffect.init(style: .light))
    
    public let elementPairs: [String: String] = ["🍎": "🌶", "☀️": "🌧", "😀": "😔", "👨🏻‍💻": "🐞", "📱": "📺", "🎶": "🔇", "🤩": "😡", "_": ";"]
    var likeElements = ["🍎", "☀️", "😀","👨🏻‍💻", "📱", "🎶", "🤩", "_"]
    
    
    public var currentValuePair = ("","")
    


    
    var index = 0
    
    
    // function which is moving the plane to its finish.
    
    func movePlane(){
        
        index += 1
        let xValue = Double(index) * 30
        
        UIView.animate(withDuration: 0.5) {
            
            if self.index >=  2 {
                self.planeEmoji.center = CGPoint(x: -(9/4) * xValue + 612.5, y: xValue + 310)
            } else {
                self.planeEmoji.center = CGPoint(x: -(9/4) * xValue + 612.5, y: xValue)
            }
        }
    }
    
    
    func checkEmoji(){
        for elementPair in self.elementPairs {
            if elementPair == self.currentValuePair{
                if let unwrappedValue = self.likeElements.lastIndex(of: elementPair.key){
                    self.likeElements.remove(at: unwrappedValue)
            
                switch elementPair.value {
                    
                case self.elementPairs["🍎"] :
                    print("Yeah, 🍎 are better than 🌶 ;)")
                    printCommands.freeLine()
                case self.elementPairs["☀️"]:
                    print("☀️ is always better!")
                    printCommands.freeLine()
                case self.elementPairs["😀"]:
                    print("Be 😀 don't 😔")
                    printCommands.freeLine()
                case self.elementPairs["👨🏻‍💻"]:
                    print("I❤️👨🏻‍💻 && 🔨, but I don't like 🐞")
                    printCommands.freeLine()
                case self.elementPairs["📱"]:
                    print("Retro is not my cup of tea!")
                    printCommands.freeLine()
                case self.elementPairs["🎶"]:
                    print("🎶 is just awesome")
                    printCommands.freeLine()
                case self.elementPairs["🤩"]:
                    print("Incredible, stunning, unbelievable, my most amazing playground yet ;) ")
                    printCommands.freeLine()
                case self.elementPairs["_"]:
                    print("Thank you for that there's no need for ; in Swift! ")
                    printCommands.freeLine()
                    
                default: printCommands.bugMessage()
                }
                self.dontLikePicker.reloadAllComponents()
                self.likePicker.reloadAllComponents()
                self.movePlane()
                Media.sharedInstance.play(MediaName: "Success")
              
                    
                    // sets the likedObject with the current selectedRow. So the currentvalue pair is set to current values even when there was a reload of the likePicker. Before that you had to select the objects manually to trigger the didselectRow delegate function and set the current values.
                    if likeElements.count > 1 {
                        self.likeObject = self.likeElements[self.likePicker.selectedRow(inComponent: 0)]
                        
                    }else if likeElements.count == 1 {
                        if let unwrappedString = self.likeElements.last{
                            self.likeObject = unwrappedString
                        }
                    }
       
                // if that happens the game is over!
                if self.likeElements.count == 0 {
                    UIView.animate(withDuration: 1.0){
                        self.bringSubviewToFront(self.topicLabel)
                        self.topicLabel.alpha = 1.0
                        Media.sharedInstance.play(MediaName: "Applause")
                        self.sendSubviewToBack(self.dontLikePicker)
                        self.endingBlurview.alpha = 1.0
                    }
                    
                    print("Well done!")
                    print("The End")
                }
            }
        }
    }
}
    
    
    
    public init() {
        super.init(frame: Constants.viewScreenFrame)

        configurationView(GenericUI: iphoneShape, Type: 4, SuperView: self, Frame: Constants.viewScreenFrame
            , image: UIImage.init(named: "Notch light.png"), Background: .clear)
        configurationView(GenericUI: endingBlurview, Type: 0, SuperView: self, Frame: Constants.viewScreenFrame
            , Background: .clear)
        endingBlurview.alpha = 0.0
        
        self.sendSubviewToBack(iphoneShape)
        
        
        
        self.frame = Constants.viewScreenFrame
        self.backgroundColor = .white
        
        
        Media.sharedInstance.play(MediaName: "Ending music")
        Media.sharedInstance.speak(text: Constants.endingText)
   
        
        
        configurationView(GenericUI: swiftIcon, Type: 4, SuperView: self
            , Frame: CGRect(x: 20, y: 50, width: 100, height: 100),  image: UIImage.init(named: "Swift logo.jpg"), Background: .clear)
        
        configurationView(GenericUI: xcodeIcon, Type: 4, SuperView: self
            , Frame: CGRect(x: 250, y: 500, width: 100, height: 100),  image: UIImage.init(named: "Xcode logo.png"), Background: .clear)
        
        configurationView(GenericUI: finderSad, Type: 4, SuperView: self
            , Frame: CGRect(x: 282, y: 170, width: 30, height: 30),  image: UIImage.init(named: "Finder sad.png"), Background: .clear)
        
        configurationView(GenericUI: finderHappy, Type: 4, SuperView: self
            , Frame: CGRect(x: 72, y: 170, width: 30, height: 30),  image: UIImage.init(named: "Finder happy.png"), Background: .clear)
        
        configurationView(GenericUI: WWDC19, Type: 4, SuperView: self
            , Frame: CGRect(x: 30, y: 500, width: 100, height: 150), Border: (cornerRadius: 30, width: 0, colour: UIColor.clear), image: UIImage.init(named: "WWDC 2019.png"), Background: .clear)
        
        configurationView(GenericUI: planeEmoji, Type: 2, SuperView: self, Frame: CGRect(x: 200, y: 50, width: 100, height: 100), Text: ("🛩", .black, 100), Background: .clear)
        planeEmoji.transform = CGAffineTransform(rotationAngle: 0.2 * (CGFloat.pi))
        
        configurationView(GenericUI: usaFlag, Type: 2, SuperView: self, Frame: CGRect(x: 60, y: 460, width: 50, height: 30), Text: ("🇺🇸", .black, 50), Background: .clear)
        
        configurationView(GenericUI: germanyFlag, Type: 2, SuperView: self, Frame: CGRect(x: 290, y: 15, width: 50, height: 30), Text: ("🇩🇪", .black, 50), Background: .clear)
        
        configurationView(GenericUI: likePicker, Type: 6, SuperView: self, Frame: CGRect.init(x: 60, y: 200, width: 50, height: 200),  Background: .clear)
        
        configurationView(GenericUI: topicLabel, Type: 2, SuperView: self, Frame: CGRect.init(x: 80, y: 300, width: 400, height: 80), Text: ("The End", .black, 60), Background: .clear)
        topicLabel.alpha = 0.0
        configurationView(GenericUI: endingBlurview, Type: 0, SuperView: self, Frame: Constants.viewScreenFrame
            , Background: .clear)
        endingBlurview.alpha = 0.0
        

        likePicker.delegate = self
        likePicker.dataSource = self
        dontLikePicker.customDelegate = self
        likePicker.layer.borderWidth = 3
        likePicker.layer.borderColor = UIColor.gray.cgColor
        likePicker.layer.cornerRadius = 20
        self.addSubview(dontLikePicker)
    }
    

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}



extension EndingScreen: UIPickerViewDataSource, UIPickerViewDelegate {
    
    public func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    public func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return likeElements.count
    }
    
    public func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return likeElements[row]
    }
    

    public func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        let label = UILabel()
        label.font = UIFont.init(name: "Helvetica", size: 25)
        label.text = likeElements[row]
        label.textAlignment = .center
        return label
    }
    
    public func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        self.likeObject = self.likeElements[row]
        self.currentValuePair.0 = likeObject
        self.currentValuePair.1 = dontLikeObject
        self.checkEmoji()
    }
}


extension EndingScreen: dontLikePickerDelegate {
    
    public func chosenPicker(emoji: String){
        self.dontLikeObject = emoji
        self.currentValuePair.0 = self.likeObject
        self.currentValuePair.1 = self.dontLikeObject
        self.checkEmoji()
    }
    
}
