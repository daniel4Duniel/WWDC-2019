//:Hi!
//:Please run my playground on macOS with Xcode and the iOS simulator.
//:I used Xcode 10.1 to develop this playground.

//: Thank You😀!
import PlaygroundSupport


PlaygroundPage.current.liveView = MainScreen()






//: Sources:
// Wallpapers WWDC:
// https://drive.google.com/drive/folders/1sQvQ7_F4UCEfS4h6Cu-vB3xtEmXSdQke
// iphone Silhouette:
// https://wallpapercave.com/w/wp3830207
// siri show me something new gif:
// https://giphy.com/gifs/siri-apple-event-2015-tv-l41lWMPkMkfIYr9zW
// siri animation gif:
// https://www.pinterest.com/pin/408490628691798498/
//screenshot gif:
//https://support.apple.com/de-de/HT200289
// slide to unlock gif:
// https://www.pinterest.com/pin/521854675558186440/
// liam robot gif:
//https://gifer.com/en/9D4z
// waste gif:
//https://gifer.com/en/9D4m
// apple logos:
//https://www.theverge.com/tldr/2018/10/18/17995368/apple-october-30th-event-custom-logo-roundup
